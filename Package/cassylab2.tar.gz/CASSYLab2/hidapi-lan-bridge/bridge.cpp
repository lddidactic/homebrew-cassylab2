#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <hidapi/hidapi.h>
#include <map>
#include <string>
#include <signal.h>

void open_device(hid_device_info* dev);
void* thread_func(void*);
void send_udp(int socket, char* msg);
int send_usb_from_socket(hid_device* dev, unsigned char* msg, int len, int usb_report_out_size);
void send_socket_from_usb(int socket, unsigned char* msg, int usb_report_in_size, int type);
void print_clock(void);
void print_hex(unsigned char* msg, int len);
void* hidthread_func(void* arg);

typedef struct {
    char name[25];
    int type;
    unsigned short pid;
    int usb_report_in_size;
    int usb_report_out_size;
} CASSYTYPE;

CASSYTYPE cassy_types[] = { 
    {"CASSY",                    1,  0x1000, 8,  8},
    {"CASSY2",                   3,  0x1001, 64, 64},
    {"PocketCASSY",              13, 0x1010, 32, 8},
    {"PocketCASSY2",             29, 0x1011, 64, 64},
    {"PocketBattery",            30, 0x1012, 64, 64},
    {"MobileCASSY",              12, 0x1020, 64, 64},
    {"MobileCASSY2",             28, 0x1021, 64, 64},
    {"MicroCASSYVoltage",        16, 0x1031, 64, 64},
    {"MicroCASSYCurrent",        17, 0x1032, 64, 64},
    {"MicroCASSYTime",           18, 0x1033, 64, 64},
    {"MicroCASSYTemperature",    20, 0x1035, 64, 64},
    {"MicroCASSYPH",             23, 0x1038, 64, 64},
    {"PowerAnalyserCASSY",       40, 0x1040, 64, 64},
    {"ConverterControllerCASSY", 42, 0x1042, 64, 64},
    {"MachineTestCASSY",         43, 0x1043, 64, 64},
    {"Jwm",                      32, 0x1080, 8,  8},
    {"DmmP",                     -1, 0x1081, 8,  8},
    {"UmiP",                     33, 0x1090, 64, 64},
    {"UmiC",                     34, 0x10a0, 64, 64},
    {"UmiB",                     35, 0x10b0, 64, 64},
};

#define CASSYTYPE_POCKET 13

typedef struct {
    int pipefd;
    CASSYTYPE* device_type;
    hid_device* dev;
    volatile bool stop;
} HidthreadData_t;

int debug = 0;
std::map<std::string,CASSYTYPE*> device_types;
pthread_mutex_t device_types_mutex = PTHREAD_MUTEX_INITIALIZER;
struct timespec clock_start;

int main(int argc, char** argv) 
{
    char c;
    // parse options
    while ((c = getopt (argc, argv, "vd:u:i:o:r:t:")) != -1) {
        switch (c) {
            case 'v':                                     // verbose mode
                debug++;
                break;
        }
    }
    signal(SIGPIPE, SIG_IGN);
    clock_gettime(CLOCK_REALTIME, &clock_start);
    hid_init();
    do {
        // monitor USB devices and create a thread to handle each new device
        if (struct hid_device_info* devinfo = hid_enumerate(0x0f11, 0)) {
            pthread_mutex_lock(&device_types_mutex);
            for (struct hid_device_info* dev = devinfo; dev; dev=dev->next) {
                if (device_types.find(dev->path) == device_types.end()) {
                    open_device(dev);
                }
            }
            pthread_mutex_unlock(&device_types_mutex);
            hid_free_enumeration(devinfo);
        }
        sleep(1);
    } while (1);
    hid_exit();

    return 0;
}

void open_device(hid_device_info* dev)
{
    // get CASSY parameters from cassy_types
    for (int i=0; i<sizeof(cassy_types)/sizeof(cassy_types[0]); i++) {
        if (cassy_types[i].pid == dev->product_id) {
            // found CASSY, spawn thread
            device_types[dev->path] = &cassy_types[i];
            pthread_attr_t threadAttr;
            pthread_attr_init(&threadAttr);
            pthread_attr_setdetachstate(&threadAttr, PTHREAD_CREATE_DETACHED);
            pthread_t thread;
            pthread_create(&thread, &threadAttr, thread_func, strdup(dev->path));
            pthread_attr_destroy(&threadAttr);
            return;
        }
    }
}

void* thread_func(void* arg)
{
    char* path = (char*)arg;
    pthread_mutex_lock(&device_types_mutex);
    CASSYTYPE* device_type = device_types[path];
    pthread_mutex_unlock(&device_types_mutex);
    char version = 0;
    if (device_type->type == CASSYTYPE_POCKET)
        version = 103;

    printf("report in size: %d\n", device_type->usb_report_in_size);
    printf("report out size: %d\n", device_type->usb_report_out_size);
    //printf("using device /dev/ldusb%d\n", ldusb);
    printf("debug: %d\n", debug);

    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);  // create UDP socket
    struct sockaddr_in udp_address;
    memset(&udp_address, 0, sizeof(udp_address));
    udp_address.sin_family = AF_INET;
    udp_address.sin_addr.s_addr = htonl(INADDR_ANY);  // do not bind to a specific interface (maybe change to 127.0.0.1)
    udp_address.sin_port = 0;                         // OS choses sender port number

    bind(udp_socket, (struct sockaddr*)&udp_address, sizeof(udp_address)); // bind addres to socket

    socklen_t udp_address_len = sizeof(udp_address);
    getsockname(udp_socket, (struct sockaddr*)&udp_address, &udp_address_len);    // retrieve info about UDP socket
    unsigned short tcp_port = udp_address.sin_port;                       // sender port is used for TCP connection


    unsigned char buf[256];
    int br, wr;
    hid_device* dev = hid_open_path(path);
    if (!dev) {
        perror("Could not open HID path\n");
        pthread_mutex_lock(&device_types_mutex);
        device_types.erase(path);
        pthread_mutex_unlock(&device_types_mutex);
        free(path);
        return (void*)1;
    }

    if (version == 0) {
        // retrieve device information
        memset(buf, 0, device_type->usb_report_out_size);
        buf[0] = 3;
        buf[1] = 27;
        buf[2] = 255;
        buf[3] = 1;
        hid_write(dev, buf, device_type->usb_report_out_size);
        br = hid_read_timeout(dev, buf, device_type->usb_report_out_size, 100);
        print_hex(buf, br);

        if (buf[2] != device_type->type) {
            printf("error: device type does not match PID\n");
        }
        version = buf[3];
    }

    // build message for UDP
    char udp_msg[64];
    sprintf(udp_msg, "CASSY=%d,%d", device_type->type, version);
    printf("found CASSY type %d, ver %d\n", device_type->type, version);

    int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);                 // create TCP socket
    int sockopt = 1;
    setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &sockopt, sizeof(int));

    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_addr.s_addr = htonl(INADDR_ANY);
    tcp_address.sin_port = tcp_port;

    bind(tcp_socket, (struct sockaddr*)&tcp_address, sizeof(tcp_address));
    listen(tcp_socket, 1);

    struct sockaddr_in client_address;          // address of client (CASSY Lab)
    socklen_t client_address_len = sizeof(client_address);

    fd_set set;                                 // file descript set for select
    struct timeval timeout;

    int accepted = 0;                           // connection status
    int pipefd[2] = {0, 0};                     // pipe to communicate with hid thread
    pthread_t hidthread;
    HidthreadData_t hidthreadData;              // data to pass to hid thread

    for(;;) {
        if (accepted) {                         // if connected, 5 s timeout
            timeout.tv_sec = 5;
            timeout.tv_usec = 0;
        } else {                                // during connecting 2 s timeout
            timeout.tv_sec = 2;
            timeout.tv_usec = 0;
        }

        FD_ZERO(&set);                          // clear set and and descriptors
        FD_SET(tcp_socket, &set);
        if (pipefd[0])
          FD_SET(pipefd[0], &set);
        int ready;
        if ((ready = select(std::max(tcp_socket, pipefd[0])+1, &set, 0, 0, &timeout)) < 1) {   // wait until data is availaible
            if (!accepted && ready == 0) {        // if not yet connected, send UDP message
                send_udp(udp_socket, udp_msg);
                continue;
            } else {                              // if connected, exit on timeout or error
                printf("timeout\n");
                break;
            }
        }

        unsigned char buf[device_type->usb_report_in_size > device_type->usb_report_out_size ? device_type->usb_report_in_size : device_type->usb_report_out_size];
        if (FD_ISSET(tcp_socket, &set)) {       // TCP socket is ready
            if (!accepted) {                      // CASSY Lab was not yet connected
                int s_new = accept(tcp_socket, (struct sockaddr*)&client_address, &client_address_len); // accept TCP connection
                close(tcp_socket);                  // close old TCP socket
                close(udp_socket);                  // close UDP socket
                tcp_socket = s_new;
                int one = 1;
                setsockopt(tcp_socket, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
                accepted = 1;
                printf("connection established on port %d\n", tcp_port);
                // start thread to read from HIDAPI
                pipe(pipefd);
                hidthreadData.dev = dev;
                hidthreadData.device_type = device_type;
                hidthreadData.pipefd = pipefd[1];
                hidthreadData.stop = false;
                pthread_create(&hidthread, NULL, hidthread_func, &hidthreadData);
                continue;
            }
            if (device_type->type == CASSYTYPE_POCKET) {
                // beim Pocket-CASSY wird das Längenbyte mitgesendet
                unsigned char len;
                br = read(tcp_socket, &len, 1);
                if (br > 0) {
                    if (len > device_type->usb_report_out_size) {
                        printf("wrong length byte received: %c\n", len);
                        break;
                    }
                    br = 0;
                    do {
                        int br2 = read(tcp_socket, &buf[br], len-br);
                        if (br2 <= 0) {             // Verbindung wurde geschlossen
                            br = br2;
                            perror("error reading payload");
                            break;
                        }
                        br += br2;
                    } while (br < len);             // soviele Bytes lesen wie laut Längenbyte gesendet wurden
                }
            } else {
                br = read(tcp_socket, buf, device_type->usb_report_out_size);
            }
            if (br <= 0) {
                printf("connection closed\n");
                break;
            }
            if (debug > 0) {
                print_clock();
                printf("received: %d bytes on socket\n", br);
            }
            if (debug > 1) {
                print_hex(buf, br);
            }
            if (send_usb_from_socket(dev, buf, br, device_type->usb_report_out_size) < 0)
                break;
        }
        if (FD_ISSET(pipefd[0], &set)) {       // data from device available
            memset(buf, 0, device_type->usb_report_in_size);
            br = read(pipefd[0], buf, device_type->usb_report_in_size);
            if (br < 0) {
              printf("removed device %s\n", path);
              break;
            }
            if (br) {
                if (debug > 0) {
                    print_clock();
                    printf("received: %d bytes on usb\n", br);
                }
                if (debug > 1) {
                    print_hex(buf, br);
                }
                if (accepted) {
                    send_socket_from_usb(tcp_socket, buf, device_type->usb_report_in_size, device_type->type);
                }
            }
        }
    }

    print_clock();
    printf("exiting device %s\n", path);

    // cleanup
    close(tcp_socket);
    close(pipefd[0]);
    hidthreadData.stop = true;
    void* ret;
    pthread_join(hidthread, &ret);
    hid_close(dev);
    pthread_mutex_lock(&device_types_mutex);
    device_types.erase(path);
    pthread_mutex_unlock(&device_types_mutex);
    if (debug) {
        print_clock();
        printf("exited device %s\n", path);
    }
    free(path);

    return 0;
}

void* hidthread_func(void* arg)
{
    HidthreadData_t* data = (HidthreadData_t*)arg;
    unsigned char buf[data->device_type->usb_report_in_size];
    while (true) {
        memset(buf, 0, data->device_type->usb_report_in_size);
        int br = hid_read_timeout(data->dev, buf, data->device_type->usb_report_in_size, 1000);
        if (br < 0)                 // removed device
            break;
        int bw = write(data->pipefd, buf, br ? data->device_type->usb_report_in_size : 0);
        if (bw < 0 || data->stop)                 // pipe was closed, shut down thread
            break;
    }
    close(data->pipefd);
    if (debug)
        printf("closing HIDAPI thread\n");
    return 0;
}

void print_clock() {
    time_t sec;
    long nsec;
    struct timespec clock_current;
    clock_gettime(CLOCK_REALTIME, &clock_current);

    sec = clock_current.tv_sec - clock_start.tv_sec;
    nsec = clock_current.tv_nsec - clock_start.tv_nsec;

    if (nsec < 0) {
      nsec += 1e9;
      sec -= 1;
    }

    printf ("%4d.%06ld: ", (int)sec, nsec / 1000);
}

// send message received from CASSY Lab via socket to USB
int send_usb_from_socket(hid_device* dev, unsigned char* msg, int len, int usb_report_out_size) {
    unsigned char buf[usb_report_out_size];
    memset(buf, 0, usb_report_out_size);               // init buffer
    if (len < usb_report_out_size) {                   // if length < usb_report_size, set first byte to length
        buf[0] = len;
        memcpy(&buf[1], msg, len);                     // message starts from second byte on
    } else {
        memcpy(buf, msg, usb_report_out_size);         // if len = usb_report_size, use complete USB packet
    }
    int bw = hid_write(dev, buf, usb_report_out_size);             // always send usb_report_size bytes

    if (debug > 0) {
        print_clock();
        printf("sent: %d (%d) bytes on usb\n", usb_report_out_size, bw);
    }
    if (debug > 1) {
        print_hex(buf, usb_report_out_size);
    }
    return bw;
}

// send message received from USB via socket to CASSY Lab
void send_socket_from_usb(int socket, unsigned char* msg, int usb_report_in_size, int type) {
    unsigned char buf[usb_report_in_size+1];
    int len;
    if (msg[0] < usb_report_in_size) {      // if first byte < usb_report_size -> length of message
        len = msg[0];
        if (type == CASSYTYPE_POCKET) {     // Pocket CASSY benötigt das Längen-Byte
            memcpy(buf, msg, ++len);
        } else {
            memcpy(buf, msg+1, len);        // copy from second byte on
        }
    } else {
        len = usb_report_in_size;
        if (type == CASSYTYPE_POCKET) {     // Pocket CASSY benötigt das Längen-Byte
            buf[0] = len;
            memcpy(&buf[1], msg, len++);
        } else {
            memcpy(buf, msg, len);          // copy from first byte on
        }
        if (debug > 1) {
            printf("length >= 32\n");
        }
    }
    write(socket, buf, len);                // only send message w/o padding

    if (debug > 0) {
        print_clock();
        printf("sent: %d bytes on socket\n", len);
    }
    if (debug > 1) {
        print_hex(buf, len);
    }
}

// send message via UDP to 127.0.0.1
void send_udp(int socket, char* msg) {
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    server_address.sin_port = htons(9001);                        // CASSY Lab listens on port 9001

    sendto(socket, msg, strlen(msg), 0, (struct sockaddr*)&server_address, sizeof(server_address));

    if (debug > 0) {
        printf("sent udp packet\n");
    }
}

// print msg as hex numbers
void print_hex(unsigned char* msg, int len) {
    if (debug >= 2) {
        int i;
        for (i = 0; i < len; i++) {
            printf("%02hhx ", msg[i]);
        }
        printf("\n");
    }
}

