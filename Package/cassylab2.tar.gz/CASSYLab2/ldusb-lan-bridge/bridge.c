#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <pthread.h>

void open_device(int ldusb);
void* thread_func(void*);
void send_udp(int socket, char* msg);
void send_usb_from_socket(int file, unsigned char* msg, int len, int usb_report_out_size);
void send_socket_from_usb(int socket, unsigned char* msg, int usb_report_in_size, int type);
void print_clock(void);
void print_hex(unsigned char* msg, int len);

typedef struct {
    char name[25];
    int type;
    unsigned short pid;
    int usb_report_in_size;
    int usb_report_out_size;
} CASSYTYPE;

CASSYTYPE cassy_types[] = { 
    {.name = "CASSY",                    .type = 1,  .pid = 0x1000, .usb_report_in_size = 8,  .usb_report_out_size = 8},
    {.name = "CASSY2",                   .type = 3,  .pid = 0x1001, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "PocketCASSY",              .type = 13, .pid = 0x1010, .usb_report_in_size = 32, .usb_report_out_size = 8},
    {.name = "PocketCASSY2",             .type = 29, .pid = 0x1011, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "PocketBattery",            .type = 30, .pid = 0x1012, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MobileCASSY",              .type = 12, .pid = 0x1020, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MobileCASSY2",             .type = 28, .pid = 0x1021, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MicroCASSYVoltage",        .type = 16, .pid = 0x1031, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MicroCASSYCurrent",        .type = 17, .pid = 0x1032, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MicroCASSYTime",           .type = 18, .pid = 0x1033, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MicroCASSYTemperature",    .type = 20, .pid = 0x1035, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MicroCASSYPH",             .type = 23, .pid = 0x1038, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "PowerAnalyserCASSY",       .type = 40, .pid = 0x1040, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "ConverterControllerCASSY", .type = 42, .pid = 0x1042, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "MachineTestCASSY",         .type = 43, .pid = 0x1043, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "Jwm",                      .type = 32, .pid = 0x1080, .usb_report_in_size = 8,  .usb_report_out_size = 8},
    {.name = "DmmP",                     .type = -1, .pid = 0x1081, .usb_report_in_size = 8,  .usb_report_out_size = 8},
    {.name = "UmiP",                     .type = 33, .pid = 0x1090, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "UmiC",                     .type = 34, .pid = 0x10a0, .usb_report_in_size = 64, .usb_report_out_size = 64},
    {.name = "UmiB",                     .type = 35, .pid = 0x10b0, .usb_report_in_size = 64, .usb_report_out_size = 64},
};

#define CASSYTYPE_POCKET 13

int debug = 0;
volatile CASSYTYPE* device_types[10] = {0};

struct timespec clock_start;

int main(int argc, char** argv) 
{
    char c;
    // parse options
    while ((c = getopt (argc, argv, "vd:u:i:o:r:t:")) != -1) {
        switch (c) {
        case 'v':                                     // verbose mode
            debug++;
            break;
        }
    }
    clock_gettime(CLOCK_REALTIME, &clock_start);
    // monitor /dev/ldusb and create a thread to handle each new device
    do {
        for (int i=0; i<10; i++) {
            if (device_types[i] == NULL) {
                char devname[20];
                sprintf(devname, "/dev/ldusb%d", i);
                if (access(devname, R_OK | W_OK) == 0) {
                    open_device(i);
                }
            }
        }
        sleep(1);
    } while (1);
}

void open_device(int ldusb)
{
    // get vendor and product id from /sys/class/usb...
    char path[256];
    sprintf(path, "/sys/class/usbmisc/ldusb%d/device/../idVendor", ldusb);
    FILE* fvendor = fopen(path, "r");
    sprintf(path, "/sys/class/usbmisc/ldusb%d/device/../idProduct", ldusb);
    FILE* fproduct = fopen(path, "r");
    if (!fvendor || !fproduct) {
        sprintf(path, "/sys/class/usb/ldusb%d/device/../idVendor", ldusb);
        fvendor = fopen(path, "r");
        sprintf(path, "/sys/class/usb/ldusb%d/device/../idProduct", ldusb);
        fproduct = fopen(path, "r");
    }
    if (!fvendor || !fproduct) {
        perror("could not open device files in /sys");
        return;
    }
    unsigned vendorId, productId;
    fscanf(fvendor, "%x", &vendorId);
    fscanf(fproduct, "%x", &productId);
    fclose(fvendor);
    fclose(fproduct);
    if (vendorId != 0x0f11)
        return;
    // get CASSY parameters from cassy_types
    for (int i=0; i<sizeof(cassy_types)/sizeof(cassy_types[0]); i++) {
        if (cassy_types[i].pid == productId) {
            // found CASSY, spawn thread
            device_types[ldusb] = &cassy_types[i];
            pthread_attr_t threadAttr;
            pthread_attr_init(&threadAttr);
            pthread_attr_setdetachstate(&threadAttr, PTHREAD_CREATE_DETACHED);
            pthread_t thread;
            pthread_create(&thread, &threadAttr, thread_func, (void*)(intptr_t)ldusb);
            pthread_attr_destroy(&threadAttr);
            return;
        }
    }
    printf("unknown PID %04x\n", productId);
}

void* thread_func(void* arg)
{
    int ldusb = (int)(intptr_t)arg;
    if (ldusb < 0 || ldusb > 9)
        return NULL;

    char version = 0;
    if (device_types[ldusb]->type == CASSYTYPE_POCKET)
        version = 103;

    printf("report in size: %d\n", device_types[ldusb]->usb_report_in_size);
    printf("report out size: %d\n", device_types[ldusb]->usb_report_out_size);
    printf("using device /dev/ldusb%d\n", ldusb);
    printf("debug: %d\n", debug);

    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);  // create UDP socket
    struct sockaddr_in udp_address;
    memset(&udp_address, 0, sizeof(udp_address));
    udp_address.sin_family = AF_INET;
    udp_address.sin_addr.s_addr = htonl(INADDR_ANY);  // do not bind to a specific interface (maybe change to 127.0.0.1)
    udp_address.sin_port = 0;                         // OS choses sender port number

    bind(udp_socket, (struct sockaddr*)&udp_address, sizeof(udp_address)); // bind addres to socket

    socklen_t udp_address_len = sizeof(udp_address);
    getsockname(udp_socket, (struct sockaddr*)&udp_address, &udp_address_len);    // retrieve info about UDP socket
    unsigned short tcp_port = udp_address.sin_port;                       // sender port is used for TCP connection


    unsigned char buf[256];
    char device_name[64];
    int device_file;
    int br;
    sprintf(device_name, "/dev/ldusb%d", ldusb);
    device_file = open(device_name, O_RDWR);
    if (device_file < 0) {
        perror("error opening ldusb device");
        device_types[ldusb] = NULL;
        return (void*)1;
    }

    if (version == 0) {
        // retrieve device information
        memset(buf, 0, device_types[ldusb]->usb_report_out_size);
        buf[0] = 3;
        buf[1] = 27;
        buf[2] = 255;
        buf[3] = 1;
        write(device_file, buf, device_types[ldusb]->usb_report_out_size);
        br = read(device_file, buf, device_types[ldusb]->usb_report_out_size);
        print_hex(buf, br);

        if (buf[2] != device_types[ldusb]->type) {
            printf("error: device type does not match PID\n");
        }
        version = buf[3];
    }

    // build message for UDP
    char udp_msg[64];
    sprintf(udp_msg, "CASSY=%d,%d", device_types[ldusb]->type, version);
    printf("found CASSY type %d, ver %d\n", device_types[ldusb]->type, version);

    int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);                 // create TCP socket
    int sockopt = 1;
    setsockopt(tcp_socket, SOL_SOCKET, SO_REUSEADDR, &sockopt, sizeof(int));

    struct sockaddr_in tcp_address;
    memset(&tcp_address, 0, sizeof(tcp_address));
    tcp_address.sin_family = AF_INET;
    tcp_address.sin_addr.s_addr = htonl(INADDR_ANY);
    tcp_address.sin_port = tcp_port;

    bind(tcp_socket, (struct sockaddr*)&tcp_address, sizeof(tcp_address));
    listen(tcp_socket, 1);

    struct sockaddr_in client_address;        // address of client (CASSY Lab)
    socklen_t client_address_len = sizeof(client_address);

    fd_set set;                               // file descript set for select
    struct timeval timeout;

    int accepted = 0;                         // connection status

    for(;;) {
        if (accepted) {                         // if connected, 5 s timeout
            timeout.tv_sec = 5;
            timeout.tv_usec = 0;
        } else {                                // during connecting 2 s timeout
            timeout.tv_sec = 2;
            timeout.tv_usec = 0;
        }

        FD_ZERO(&set);                          // clear set and and descriptors
        FD_SET(tcp_socket, &set);
        FD_SET(device_file, &set);
        int ready;
        if ((ready = select(FD_SETSIZE, &set, 0, 0, &timeout)) < 1) {   // wait until data is availaible
            if (!accepted && ready == 0) {        // if not yet connected, send UDP message
                send_udp(udp_socket, udp_msg);
                continue;
            } else {                              // if connected, exit on timeout or error
                printf("timeout\n");
                break;
            }
        }

        unsigned char buf[device_types[ldusb]->usb_report_in_size > device_types[ldusb]->usb_report_out_size ? device_types[ldusb]->usb_report_in_size : device_types[ldusb]->usb_report_out_size];
        if (FD_ISSET(tcp_socket, &set)) {       // TCP socket is ready
            if (!accepted) {                      // CASSY Lab was not yet connected
                int s_new = accept(tcp_socket, (struct sockaddr*)&client_address, &client_address_len); // accept TCP connection
                close(tcp_socket);                  // close old TCP socket
                close(udp_socket);                  // close UDP socket
                tcp_socket = s_new;
                int one = 1;
                setsockopt(tcp_socket, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
                accepted = 1;
                printf("connection established on port %d\n", tcp_port);
                continue;
            }
            if (device_types[ldusb]->type == CASSYTYPE_POCKET) {
                // beim Pocket-CASSY wird das Längenbyte mitgesendet
                unsigned char len;
                br = read(tcp_socket, &len, 1);
                if (br > 0) {
                    if (len > device_types[ldusb]->usb_report_out_size) {
                        printf("wrong length byte received: %c\n", len);
                        break;
                    }
                    br = 0;
                    do {
                        int br2 = read(tcp_socket, &buf[br], len-br);
                        if (br2 <= 0) {             // Verbindung wurde geschlossen
                            br = br2;
                            perror("error reading payload");
                            break;
                        }
                        br += br2;
                    } while (br < len);             // soviele Bytes lesen wie laut Längenbyte gesendet wurden
                }
            } else {
                br = read(tcp_socket, buf, device_types[ldusb]->usb_report_out_size);
            }
            if (br <= 0) {
                printf("connection closed\n");
                break;
            }
            if (debug > 0) {
                print_clock();
                printf("received: %d bytes on socket\n", br);
            } 
            if (debug > 1) {
                print_hex(buf, br);
            }
            send_usb_from_socket(device_file, buf, br, device_types[ldusb]->usb_report_out_size);
        }
        if (FD_ISSET(device_file, &set)) {
            br = read(device_file, buf, device_types[ldusb]->usb_report_in_size);
            if (br < 0) {
                printf("removed device /dev/ldusb%d\n", ldusb);
                break;
            }
            if (debug > 0) {
                print_clock();
                printf("received: %d bytes on usb\n", br);
            } 
            if (debug > 1) {
                print_hex(buf, br);
            }
            if (accepted) {
                send_socket_from_usb(tcp_socket, buf, device_types[ldusb]->usb_report_in_size, device_types[ldusb]->type);
            }
        }
    }

    printf("exiting device /dev/ldusb%d\n", ldusb);

    // cleanup
    close(tcp_socket);
    close(device_file);
    device_types[ldusb] = NULL;

    return 0;
}

void print_clock() {
    time_t sec; 
    long nsec;   
    struct timespec clock_current;
    clock_gettime(CLOCK_REALTIME, &clock_current);

    sec = clock_current.tv_sec - clock_start.tv_sec;
    nsec = clock_current.tv_nsec - clock_start.tv_nsec;

    if (nsec < 0) {
      nsec += 1e9;
      sec -= 1;
    }

    printf ("%4d.%06ld: ", (int)sec, nsec / 1000);
}

// send message received from CASSY Lab via socket to USB
void send_usb_from_socket(int file, unsigned char* msg, int len, int usb_report_out_size) {
    unsigned char buf[usb_report_out_size];
    memset(buf, 0, usb_report_out_size);               // init buffer
    if (len < usb_report_out_size) {                   // if length < usb_report_size, set first byte to length
        buf[0] = len;
        memcpy(&buf[1], msg, len);                     // message starts from second byte on
    } else {
        memcpy(buf, msg, usb_report_out_size);         // if len = usb_report_size, use complete USB packet
    }
    write(file, buf, usb_report_out_size);             // always send usb_report_size bytes

    if (debug > 0) {
        print_clock();
        printf("sent: %d bytes on usb\n", usb_report_out_size);
    } 
    if (debug > 1) {
        print_hex(buf, usb_report_out_size);
    }
}

// send message received from USB via socket to CASSY Lab
void send_socket_from_usb(int socket, unsigned char* msg, int usb_report_in_size, int type) {
    unsigned char buf[usb_report_in_size+1];
    int len;
    if (msg[0] < usb_report_in_size) {      // if first byte < usb_report_size -> length of message
        len = msg[0];
        if (type == CASSYTYPE_POCKET) {     // Pocket CASSY benötigt das Längen-Byte
            memcpy(buf, msg, ++len);
        } else {
            memcpy(buf, msg+1, len);        // copy from second byte on
        }
    } else {
        len = usb_report_in_size;
        if (type == CASSYTYPE_POCKET) {     // Pocket CASSY benötigt das Längen-Byte
            buf[0] = len;
            memcpy(&buf[1], msg, len++);
        } else {
            memcpy(buf, msg, len);          // copy from first byte on
        }
        if (debug > 1) {
          printf("length >= 32\n");
        }
    }
    write(socket, buf, len);                // only send message w/o padding

    if (debug > 0) {
        print_clock();
        printf("sent: %d bytes on socket\n", len);
    } 
    if (debug > 1) {
        print_hex(buf, len);
    }
}

// send message via UDP to 127.0.0.1
void send_udp(int socket, char* msg) {
    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr("127.0.0.1");
    //server_address.sin_addr.s_addr = inet_addr("192.168.30.228");
    //server_address.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    server_address.sin_port = htons(9001);                        // CASSY Lab listens on port 9001

    sendto(socket, msg, strlen(msg), 0, (struct sockaddr*)&server_address, sizeof(server_address));

    if (debug > 0) {
        printf("sent udp packet\n");
    }
}

// print msg as hex numbers
void print_hex(unsigned char* msg, int len) {
    if (debug >= 2) {
        int i;
        for (i = 0; i < len; i++) {
            printf("%02hhx ", msg[i]);
        }
        printf("\n");
    }
}

