#!/bin/bash

wget -V &> /dev/null || { echo >&2 "The following program is required for installation: wget"; EXIT="1"; }
gcc -v &> /dev/null || { echo >&2 "The following program is required for installation: gcc"; EXIT="1"; }
make -v &> /dev/null || { echo >&2 "The following program is required for installation: make"; EXIT="1"; }
cabextract -v &> /dev/null || { echo >&2 "The following program is required for installation: cabextract"; EXIT="1"; }
echo "#include <unistd.h>" | gcc -E - &> /dev/null || { echo >&2 "Include file unistd.h missing.\
 Please install required package, e.g.: libc6-dev"; EXIT="1"; }
wine --version &> /dev/null || { echo >&2 "The following program is required for installation: wine"; EXIT="1"; }
WINE_MAJOR=`wine --version 2> /dev/null | cut -d '-' -f2 | cut -d '.' -f 1`
WINE_MINOR=`wine --version 2> /dev/null | cut -d '.' -f 2`
if [[ $WINE_MAJOR -lt 2 && $WINE_MINOR -lt 6 ]]; then 
  echo >&2 "At least wine version 1.6 is required. Version ${WINE_MAJOR}.${WINE_MINOR} is installed.\
 Please see e.g. http://www.yourownlinux.com/2014/01/how-to-install-wine-1-6-2-in-linux.html for installation instructions on older Ubuntu/Mint distributions."
  EXIT="1"
fi

if [ "$EXIT" = "1" ]; then
  echo "Some missing/incompatible components found. Aborting installation"
  exit 1
fi


command -v wget &> /dev/null || { echo >&2 "I require wget but it's not installed.  Aborting."; exit 1; }
command -v wine &> /dev/null || { echo >&2 "I require wine but it's not installed.  Aborting."; exit 1; }
command -v gcc &> /dev/null || { echo >&2 "I require gcc but it's not installed.  Aborting."; exit 1; }
command -v make &> /dev/null || { echo >&2 "I require make but it's not installed.  Aborting."; exit 1; }

rm -f install.log
date >> install.log
wine --version >> install.log

OLD_PREFIX=$WINEPREFIX
export WINEPREFIX=~/.wine_cassylab2
export WINEARCH=win32
export WINEDEBUG=-all

exec 5>&1

exit_error()
{
  echo $1 >&5
  exit
}

echo ------------------------
echo CASSY Lab 2 Installation
echo ------------------------
echo

read -p "Install in wine prefix $WINEPREFIX [y/N]? " -n 1 ans
echo 
if [ -z "$ans" ] || [ "$ans" != "y" ] && [ "$ans" != "Y" ]; then
  exit;
fi

echo If you\'re asked to install Mono and/or Gecko, please hit Cancel.

wineboot >> install.log 2>&1
wine regedit -s reg

echo Downloading CASSY Lab 2.
wget --quiet -O cassylab2.msi http://www.ld-didactic.de/software/cassylab2_de.msi || \
  exit_error "Cannot download CASSY Lab 2. Please check internet connection."

echo Installing prerequisistes\; this might take a while.
{
  # get winetricks script
  wget -O winetricks https://raw.githubusercontent.com/Winetricks/winetricks/master/src/winetricks || \
    exit_error "Cannot download necessary file. Please check internet connection."
  chmod +x winetricks 
  ./winetricks dotnet20sp2 corefonts tahoma # install .NET and fonts
  ./winetricks -q dotnet20sp2 # fails on first try e.g. on Mint 18
} >> install.log 2>&1

echo Installing CASSY Lab 2.
{
  wine msiexec /i cassylab2.msi /quiet # install CASSY-Lab

  sleep 10
  rm -f ~/.local/share/applications/wine/Programs/CASSY\ Lab\ 2.desktop  # automatically installed by wine, remove and install own files, but does not appear immediately
  rm -f ~/.config/menus/applications-merged/wine-Programs-CASSY\ Lab\ 2.menu
  DESKTOP=$(xdg-user-dir DESKTOP 2>/dev/null || echo ~/Desktop)
  rm -f "$DESKTOP/CASSY Lab 2.lnk"
  rm -f "$DESKTOP/CASSY Lab 2.desktop"


  # make bridge
  cd ldusb-lan-bridge
  make clean 
  make || exit_error "Error compiling helper application."
  install cassybridge $WINEPREFIX
  cd ..
} >> install.log 2>&1

echo Please select language
select LANG in "de-DE" "en-US" "en-GB" "es-ES" "fr-FR" "it-IT" "nl-NL" "pt-PT" "ru-RU"; do
  case $LANG in
    *)
      break
      ;;
  esac
done

sed -e "s!\\\$\\\$\\\$PREFIX\\\$\\\$\\\$!$WINEPREFIX!g" -e "s!\\\$\\\$\\\$LANG\\\$\\\$\\\$!$LANG!g" cassylab2.sh_ > cassylab2.sh
install cassylab2.sh $WINEPREFIX

echo "Installing file associations and shortcut."
{
  sed -e "s!\\\$\\\$\\\$PREFIX\\\$\\\$\\\$!$WINEPREFIX!g" cassylab2.desktop_ > cassylab2.desktop
  sed -e "s!\\\$\\\$\\\$PREFIX\\\$\\\$\\\$!$WINEPREFIX!g" extension-ld-cassylab2.desktop_ > extension-ld-cassylab2.desktop
  mkdir -p ~/.local/share/applications
  install -m 644 extension-ld-cassylab2.desktop  cassylab2.desktop ~/.local/share/applications

  mkdir -p ~/.local/share/icons/hicolor/48x48/apps
  install -m 644 cassylab2_{1,2}.png ~/.local/share/icons/hicolor/48x48/apps/

  mkdir -p ~/.local/share/mime/packages
  install -m 644 application-ld-cassylab2.xml ~/.local/share/mime/packages/

  command -v update-desktop-database && update-desktop-database ~/.local/share/applications || RESTART=1
  command -v update-mime-database && update-mime-database ~/.local/share/mime || RESTART=1
} >> install.log 2>&1

echo Installation succesful!

if [ ! -e /etc/udev/rules.d/48-ldusb.rules ]; then
  echo Please run \'cp 48-ldusb.rules /etc/udev/rules.d/48-ldusb.rules\' as root once.
fi 

if [ RESTART = 1 ]; then
  echo Please log off and log on again or restart.
fi
