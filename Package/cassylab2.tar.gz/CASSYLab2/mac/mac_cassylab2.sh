#!/bin/bash

date > install.log
{
# Homebrew installieren falls noch nicht vorhanden
which -s brew
if [[ $? != 0 ]] ; then
	/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
else
	brew update
fi

# Wine installieren
which -s wine
if [[ $? != 0 ]] ; then
	brew install wine
	if [[ $? != 0 ]] ; then
		echo "Error installing Wine"
		exit 1
	fi
	# Wine initialisieren
	WINEARCH=win32 winecfg
	if [[ $? != 0 ]] ; then
		echo "Error initializing Wine"
		exit 1
	fi
else
	echo "Wine already installed: "
	wine --version
fi

# cassylab2 installieren
brew tap lddidactic/cassylab2 && brew install cassylab2
if [[ $? != 0 ]] ; then
	echo "Error installing cassylab2"
	exit 1
fi
ln -s /usr/local/Cellar/cassylab2/2.22/cassylab2.app /Applications/

} | tee -a install.log

echo ==============================================================
echo "Installation finished"
echo "You can now start CASSY Lab 2 from Launchpad"
echo ==============================================================
